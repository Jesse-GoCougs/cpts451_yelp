﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Npgsql;

namespace Milestone1
{
    /// <summary>
    /// Interaction logic for BusinessDetails.xaml
    /// </summary>
    public partial class BusinessTips : Window
    {
        private string bid = "";

        public class Tips
        {
            public string uid { get; set; }

            public string date { get; set; }

            public string name { get; set; }

            public string likes { get; set; }

            public string text { get; set; }
        }

        public class FriendTips
        {
            public string name { get; set; }

            public string date { get; set; }

            public string text { get; set; }
        }

        public BusinessTips(string bid)
        {
            InitializeComponent();
            this.bid = String.Copy(bid);
            likeButton.IsEnabled = false;
            addColumns2Grid();
            loadBusinessDetails();
            loadTipsTables();
        }

        private void addColumns2Grid()
        {
            DataGridTextColumn col1= new DataGridTextColumn();
            col1.Binding = new Binding("date");
            col1.Header = "Date";
            col1.Width = 100;
            tipGrid.Columns.Add(col1);

            DataGridTextColumn col2 = new DataGridTextColumn();
            col2.Binding = new Binding("name");
            col2.Header = "User Name";
            col2.Width = 100;
            tipGrid.Columns.Add(col2);

            DataGridTextColumn col3 = new DataGridTextColumn();
            col3.Binding = new Binding("likes");
            col3.Header = "Likes";
            col3.Width = 100;
            tipGrid.Columns.Add(col3);

            DataGridTextColumn col4 = new DataGridTextColumn();
            col4.Binding = new Binding("text");
            col4.Header = "Text";
            col4.Width = 400;
            tipGrid.Columns.Add(col4);

            DataGridTextColumn col5 = new DataGridTextColumn();
            col5.Binding = new Binding("name");
            col5.Header = "User Name";
            col5.Width = 100;
            friendsTips.Columns.Add(col5); //add name column

            DataGridTextColumn col6 = new DataGridTextColumn();
            col6.Binding = new Binding("date");
            col6.Header = "Date";
            col6.Width = 100;
            friendsTips.Columns.Add(col6); // add date column

            DataGridTextColumn col7 = new DataGridTextColumn();
            col7.Binding = new Binding("text");
            col7.Header = "Text";
            col7.Width = 400;
            friendsTips.Columns.Add(col7); //add text column
        }

        private string buildConnectionString()
        {
            return "Host = localhost; Username = postgres; Database = yelp; password = 305871";
        }

        //This execute query funtcion is for queries on the business tables, returns multiple rows
        private void executeQuery(string sqlstr, Action<NpgsqlDataReader> myf)
        {
            using (var connection = new NpgsqlConnection(buildConnectionString()))
            {
                connection.Open();
                using (var cmd = new NpgsqlCommand())
                {
                    cmd.Connection = connection;
                    cmd.CommandText = sqlstr;
                    try
                    {
                        var reader = cmd.ExecuteReader();
                        while (reader.Read())
                        {
                            myf(reader);
                        }
                    }
                    catch (NpgsqlException ex)
                    {
                        Console.WriteLine(ex.Message.ToString());
                        System.Windows.MessageBox.Show("SQL Error - " + ex.Message.ToString());

                    }
                    finally
                    {
                        connection.Close();
                    }
                }
            }
        }

        //this executequery function is for other queries, returns  a single item
        private void executeQuery2(string sqlstr, Action<NpgsqlDataReader> myf)
        {
            using (var connection = new NpgsqlConnection(buildConnectionString()))
            {
                connection.Open();
                using (var cmd = new NpgsqlCommand())
                {
                    cmd.Connection = connection;
                    cmd.CommandText = sqlstr;
                    try
                    {
                        var reader = cmd.ExecuteReader();
                        reader.Read(); //since business_ids are unique, the query always returns a single value
                        myf(reader);
                    }
                    catch (NpgsqlException ex)
                    {
                        Console.WriteLine(ex.Message.ToString());
                        System.Windows.MessageBox.Show("SQL Error - " + ex.Message.ToString());

                    }
                    finally
                    {
                        connection.Close();
                    }
                }
            }
        }

        private void loadBusinessDetails()
        {
            string sqlStr = "SELECT numTips FROM business WHERE b_id = '" + this.bid + "';";
            executeQuery(sqlStr, getTipCount);
        }

        private void loadTipsTables()
        {
            tipGrid.Items.Clear();
            friendsTips.Items.Clear();
            string sqlStr = "SELECT tip_date, name, likes, text, users.u_id FROM tip, users WHERE b_id = '" + this.bid + "' AND users.u_id = tip.u_id ;";
            executeQuery(sqlStr, addBusinessTips);
            
        }
        private void addBusinessTips(NpgsqlDataReader R)
        {
            tipGrid.Items.Add(new Tips() { date = R.GetTimeStamp(0).ToString(), name = R.GetString(1), likes = R.GetInt16(2).ToString(), text = R.GetString(3), uid = R.GetString(4) });
            string sqlStr = "SELECT  name, tip_date, text FROM tip, users, friends WHERE b_id = '" + this.bid + "' AND friends.u_id = tip.u_id AND friend_id = '" + R.GetString(4) + "' AND friends.u_id = users.u_id;";
            executeQuery(sqlStr, addFriendsTips);
        }

        private void addFriendsTips(NpgsqlDataReader R)
        {
            friendsTips.Items.Add(new FriendTips() { name = R.GetString(0), date = R.GetTimeStamp(1).ToString(), text = R.GetString(2) });
        }

        private void getTipCount(NpgsqlDataReader R)
        {
            numtipcount.Content = R.GetInt16(0).ToString();
        }

        private void addTip(NpgsqlDataReader R)
        {
            string sqlStr = "SELECT numTips FROM business WHERE b_id = '" + this.bid + "';"; 
            executeQuery2(sqlStr, getTipCount);
        }

        private void addtipbutton_Click(object sender, RoutedEventArgs e)
        {
            if (tiptextBox.Text.Length > 0)
            {
                string sqlStr = "INSERT INTO tip (b_id, u_id, tip_date, text, likes) VALUES ('" + bid + "','8bdxZyVvPuH-Ics5y1k_9g ','2020-03-27 13:00','" + tiptextBox.Text + "',0);";
                executeQuery2(sqlStr, addTip);
                loadTipsTables();
            }
        }

        private void tips_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            likeButton.IsEnabled = true;
        }

        private void likeButton_Click(object sender, RoutedEventArgs e)
        {
            Tips T = tipGrid.Items[tipGrid.SelectedIndex] as Tips;
            string sqlStr = "UPDATE tip SET likes = (likes + 1) WHERE u_id = '" + T.uid + "' AND tip_date = '" + T.date + "';";
            executeQuery2(sqlStr, addTip);
            loadTipsTables();
            likeButton.IsEnabled = false;
        }
    }
}
