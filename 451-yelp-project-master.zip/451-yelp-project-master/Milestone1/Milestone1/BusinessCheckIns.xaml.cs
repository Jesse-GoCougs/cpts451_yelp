﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Npgsql;
namespace Milestone1
{
    /// <summary>
    /// Interaction logic for BusinessCheckIns.xaml
    /// </summary>
    public partial class BusinessCheckIns : Window
    {
        private string bid = "";

        public BusinessCheckIns(string bid)
        {
            InitializeComponent();
            this.bid = String.Copy(bid);
            columnChart();
            chartLegend.Items.Add("1 - January");
            chartLegend.Items.Add("2 - February");
            chartLegend.Items.Add("3 - March");
            chartLegend.Items.Add("4 - April");
            chartLegend.Items.Add("5 - May");
            chartLegend.Items.Add("6 - June");
            chartLegend.Items.Add("7 - July");
            chartLegend.Items.Add("8 - August");
            chartLegend.Items.Add("9 - September");
            chartLegend.Items.Add("10 - October");
            chartLegend.Items.Add("11 - November");
            chartLegend.Items.Add("12 - December");
        }

        private void columnChart()
        {
            List<KeyValuePair<string, int>> myChartData = new List<KeyValuePair<string, int>>();
            using (var conn = new NpgsqlConnection("Host=localhost; Username=postgres; Password=305871; Database=yelp")) 
            {
                conn.Open();
                using (var cmd = new NpgsqlCommand())
                {
                    cmd.Connection = conn;

                    //Retrieve all rows
                    cmd.CommandText = "SELECT EXTRACT(MONTH FROM date), COUNT(DISTINCT date) FROM check_in WHERE check_in.b_id ='" + this.bid + "' GROUP BY EXTRACT(MONTH FROM date);";
                    using (var reader = cmd.ExecuteReader())
                    {
                        while(reader.Read())
                        {
                            myChartData.Add(new KeyValuePair<string, int>(reader.GetDouble(0).ToString(), reader.GetInt32(1)));
                        }
                    }
                }
                CheckInsChart.DataContext = myChartData;
   
            }
        }
    }
}
