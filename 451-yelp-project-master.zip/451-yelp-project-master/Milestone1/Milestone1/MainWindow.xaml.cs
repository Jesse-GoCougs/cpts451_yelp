﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Npgsql;

namespace Milestone1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public class Business
        {
            public string bid { get; set; }

            public string name { get; set; }

            public string state { get; set; }

            public string city { get; set; }

            public string zip { get; set;  }
        }

        public class Category
        {
            public string cname { get; set; }
        }

        public class Attributes
        {
            public string name { get; set; }
        }

        List<string> categories;

        public MainWindow()
        {
            InitializeComponent();
             categories = new List<string>();
            addState();
            addColumns2Grid();
            showCheckInsButton.IsEnabled = false;
            showTipsButton.IsEnabled = false;
        }

        private string buildConnectionString()
        {
            return "Host = localhost; Username = postgres; Database = postgres; password = Gocougs2020";
        }

        private void addState()
        {
            using (var connection = new NpgsqlConnection(buildConnectionString()))
            {
                connection.Open();
                using (var cmd = new NpgsqlCommand())
                {
                    cmd.Connection = connection;
                    cmd.CommandText = "SELECT distinct state FROM business ORDER BY state";
                    try
                    {
                        var reader = cmd.ExecuteReader();
                        while (reader.Read())
                        {
                            stateList.Items.Add(reader.GetString(0));
                        }
                    }
                    catch (NpgsqlException ex)
                    {
                        Console.WriteLine(ex.Message.ToString());
                        System.Windows.MessageBox.Show("SQL Error - " + ex.Message.ToString());

                    }
                    finally
                    {
                        connection.Close();
                    }
                }
            }
        }

        private void addColumns2Grid()
        {
            DataGridTextColumn col1 = new DataGridTextColumn();
            col1.Binding = new Binding("name");
            col1.Header = "BusinessName";          
            col1.Width = 255;
            businessGrid.Columns.Add(col1);

            DataGridTextColumn col2 = new DataGridTextColumn();
            col2.Binding = new Binding("state");
            col2.Header = "State";
            col2.Width = 60;
            businessGrid.Columns.Add(col2);

            DataGridTextColumn col3 = new DataGridTextColumn();
            col3.Binding = new Binding("city");
            col3.Header = "City";
            col3.Width = 150;
            businessGrid.Columns.Add(col3);

            DataGridTextColumn col4 = new DataGridTextColumn();
            col4.Binding = new Binding("zip");
            col4.Header = "Zipcode";
            col4.Width = 70;
            businessGrid.Columns.Add(col4);


            DataGridTextColumn col6 = new DataGridTextColumn();
            col6.Binding = new Binding("cname");
            col6.Header = "categories";
            col6.Width = 140;
            businessCategories.Columns.Add(col6);

            DataGridTextColumn col7 = new DataGridTextColumn();
            col7.Binding = new Binding("name");
            col7.Header = "Attributes";
            col7.Width = 140;
            businessAttributes.Columns.Add(col7);
        }

        private void executeQuery(string sqlstr, Action<NpgsqlDataReader> myf)
        {
            using (var connection = new NpgsqlConnection(buildConnectionString()))
            {
                connection.Open();
                using (var cmd = new NpgsqlCommand())
                {
                    cmd.Connection = connection;
                    cmd.CommandText = sqlstr;
                    try
                    {
                        var reader = cmd.ExecuteReader();
                        while (reader.Read())
                        {
                            myf(reader);
                        }
                    }
                    catch (NpgsqlException ex)
                    {
                        Console.WriteLine(ex.Message.ToString());
                        System.Windows.MessageBox.Show("SQL Error - " + ex.Message.ToString());

                    }
                    finally
                    {
                        connection.Close();
                    }
                }
            }
        }

        private void addCity(NpgsqlDataReader R)
        {
            cityList.Items.Add(R.GetString(0));
        }

        private void StateList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            cityList.Items.Clear();
            zipList.Items.Clear();
            if (stateList.SelectedIndex > -1)
            {
                string sqlStr = "SELECT distinct city FROM business WHERE state = '" + stateList.SelectedItem.ToString() + "' ORDER BY city";
                executeQuery(sqlStr, addCity);
            }
        }

        private void addZip(NpgsqlDataReader R)
        {
            zipList.Items.Add(R.GetString(0));
        }

        private void addAttributes(NpgsqlDataReader R)
        {
            businessAttributes.Items.Add(new Attributes() { name = R.GetString(0) });
        }
        private void CityList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            zipList.Items.Clear();
            if (cityList.SelectedIndex > -1)
            {
                string sqlStr = "SELECT distinct zip FROM business WHERE state = '" + stateList.SelectedItem.ToString() + "' AND city = '" + cityList.SelectedItem.ToString() + "' ORDER BY zip;";
                executeQuery(sqlStr, addZip);
            }
        }

        private void addGridRow(NpgsqlDataReader R)
        { 
            businessGrid.Items.Add(new Business() { name = R.GetString(0), state = R.GetString(1), city = R.GetString(2), zip = R.GetString(3), bid = R.GetString(4) });
        }

        private void addBusinessInfo(NpgsqlDataReader R)
        {
            businessName.Content = R.GetString(0);
            businessAddress.Content = R.GetString(1);
            businessCategories.Items.Add(new Category() { cname = R.GetString(2) });

        }

        private void getHours(NpgsqlDataReader R)
        {
            businessHours.Content = "Today(" + R.GetString(0) + "):    Hours: " + R.GetString(1);

        }

        private void listBoxDataBinding(NpgsqlDataReader R)
        {
            string input = R.GetString(0);
            string[] cats = input.Split(',');
            foreach (string cat in cats) {
                if (!categories.Contains(cat))
                {
                    categories.Add(cat);
                }
            }
            categorieslistBox.ItemsSource = categories;
        }

        private void zipList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            businessGrid.Items.Clear();
            categories.Clear();
            if (zipList.SelectedIndex > -1)
            {
                string sqlStr = "SELECT name, state, city, zip, b_id FROM business WHERE state = '" + stateList.SelectedItem.ToString() + "' AND city = '" + cityList.SelectedItem.ToString() + "' AND zip = '" + zipList.SelectedItem.ToString() + "' ORDER BY name;";
                executeQuery(sqlStr, addGridRow);
            }
        }

        private void BusinessGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (businessGrid.SelectedIndex > -1)
            {
                Business B = businessGrid.Items[businessGrid.SelectedIndex] as Business;
                if((B.bid != null) && (B.bid.ToString().CompareTo("") != 0))
                {
                   showCheckInsButton.IsEnabled = true;
                   showTipsButton.IsEnabled = true;
                   string sqlStr = "SELECT business.name, address, categories.name FROM business, categories WHERE business.b_id = '" + B.bid + "' AND categories.b_id = '" + B.bid + "';" ;
                   executeQuery(sqlStr, addBusinessInfo);
                   sqlStr = "SELECT name FROM attributes WHERE b_id = '" + B.bid + "' AND info != 'False';";
                   executeQuery(sqlStr, addAttributes);
                   DayOfWeek day = DateTime.Today.DayOfWeek;
                   sqlStr = "SELECT day, hours FROM hours WHERE b_id = '" + B.bid + "' AND day = '" + day.ToString()+ "';";
                   executeQuery(sqlStr, getHours);
                }
            }
        }

        private void searchbutton_Click(object sender, RoutedEventArgs e)
        {
            businessGrid.Items.Clear();
            if (categorieslistBox.SelectedItems.Count > 0)
            {
                string sqlStr = "SELECT ";
                executeQuery(sqlStr, addGridRow);
            }
        }

        private void showTipsButton_Click(object sender, RoutedEventArgs e)
        {
            Business B = businessGrid.Items[businessGrid.SelectedIndex] as Business;
            BusinessTips businessWindow = new BusinessTips(B.bid);
            businessWindow.Show();
        }

        private void showCheckInsButton_Click(object sender, RoutedEventArgs e)
        {
            Business B = businessGrid.Items[businessGrid.SelectedIndex] as Business;
            BusinessCheckIns checkinWindow = new BusinessCheckIns(B.bid);
            checkinWindow.Show();
        }
    }
}
